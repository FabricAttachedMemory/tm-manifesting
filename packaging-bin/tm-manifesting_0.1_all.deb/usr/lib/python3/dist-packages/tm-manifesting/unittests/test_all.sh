#!/bin/bash

./test_package_0ad_data.py -q
./test_package_album.py -q
./test_task.py -q
./test_tmcmd_module.py -q
