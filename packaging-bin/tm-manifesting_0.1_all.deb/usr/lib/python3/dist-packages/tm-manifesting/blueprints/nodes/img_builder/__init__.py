from . import *
from . import cfg

default_cfg = cfg.default.execute
default = cfg.default